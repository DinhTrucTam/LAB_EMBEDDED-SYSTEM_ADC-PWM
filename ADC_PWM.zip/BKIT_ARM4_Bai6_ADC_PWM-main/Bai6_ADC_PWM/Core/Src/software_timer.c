/*
 * software_timer.c
 *
 *  Created on: Sep 24, 2023
 *      Author: HaHuyen
 */

#include "software_timer.h"

#define TIMER_CYCLE_2 1


uint16_t flag_timer2 = 0;
uint16_t timer2_counter = 0;
uint16_t timer2_MUL = 0;

//software timer for clock variable
uint16_t flag_timer_clock = 0;
uint16_t timer_counter_clock = 0;
uint16_t timer_MUL_clock = 0;

//software timer for colon
uint16_t flag_timer_colon = 0;
uint16_t timer_counter_colon = 0;
uint16_t timer_MUL_colon = 0;

//software timer for alarm
uint16_t flag_timer_alarm = 0;
uint16_t timer_counter_alarm = 0;
uint16_t timer_MUL_alarm = 0;

void timer_init(){
	HAL_TIM_Base_Start_IT(&htim2);
}

void setTimer2(uint16_t duration){
	timer2_MUL = duration/TIMER_CYCLE_2;
	timer2_counter = timer2_MUL;
	flag_timer2 = 0;
}

void setTimerforClock(uint16_t duration){
	timer_MUL_clock = duration/TIMER_CYCLE_2;
	timer_counter_clock = timer_MUL_clock;
	flag_timer_clock = 0;
}

void setTimerforColon(uint16_t duration){
	timer_MUL_colon = duration/TIMER_CYCLE_2;
	timer_counter_colon = timer_MUL_colon;
	flag_timer_colon = 0;
}

void setTimerforAlarm(uint16_t duration)
{
	timer_MUL_alarm = duration/TIMER_CYCLE_2;
	timer_counter_alarm = timer_MUL_alarm;
	flag_timer_alarm = 0;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	if(htim->Instance == TIM2){
		if(timer2_counter > 0){
			timer2_counter--;
			if(timer2_counter == 0) {
				flag_timer2 = 1;
				timer2_counter = timer2_MUL;
			}
		}

		// Counter for clock
		if(timer_counter_clock > 0)
		{
			timer_counter_clock--;
			if (timer_counter_clock == 0)
			{
				flag_timer_clock = 1;
				timer_counter_clock = timer_MUL_clock;
			}
		}

		// Counter for colon
		if(timer_counter_colon > 0)
		{
			timer_counter_colon--;
			if (timer_counter_colon == 0)
			{
				flag_timer_colon = 1;
				timer_counter_colon = timer_MUL_colon;
			}
		}

		// Counter for alarm
		if(timer_counter_alarm > 0)
		{
			timer_counter_alarm--;
			if (timer_counter_alarm == 0)
			{
				flag_timer_alarm = 1;
				timer_counter_alarm = timer_MUL_alarm;
			}
		}
		// 1ms interrupt here
		led7_Scan();
	}
}

